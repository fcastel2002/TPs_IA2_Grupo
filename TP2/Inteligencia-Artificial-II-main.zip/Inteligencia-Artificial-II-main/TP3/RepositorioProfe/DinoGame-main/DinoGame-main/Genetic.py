import random
import numpy as np

def updateNetwork(population):
    # ===================== ESTA FUNCIÓN RECIBE UNA POBLACIÓN A LA QUE SE DEBEN APLICAR MECANISMOS DE SELECCIÓN, =================
    # ===================== CRUCE Y MUTACIÓN. LA ACTUALIZACIÓN DE LA POBLACIÓN SE APLICA EN LA MISMA VARIABLE ====================
    pass



    # =============================================================================================================================

def select_fittest(population):
    # ===================== FUNCIÓN DE SELECCIÓN =====================
    pass



    # ================================================================

def evolve(element1, element2):
    # ===================== FUNCIÓN DE CRUCE Y MUTACIÓN =====================
    pass



    # ===============================================================
    