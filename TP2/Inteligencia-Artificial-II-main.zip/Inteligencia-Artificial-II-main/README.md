# Inteligencia-Artificial-II
Repositorio para ir poniendo todas las cosas de IA II. Trabajos y demas.
